export const dummyTodoList = [
  {
    id: Math.random(),
    title: "Check Mails",
    description: "Check if there are any new mails.",
    dateCreated: new Date().toLocaleDateString(),
    completed: false,
    dateCompleted: "",
  },
  {
    id: Math.random(),
    title: "Pay rent",
    description: "Check for the utilities bills as well.",
    dateCreated: new Date().toLocaleDateString(),
    completed: false,
    dateCompleted: "",
  },
  {
    id: Math.random(),
    title: "Pay tution fee",
    description: "Check if the CTA pass fee is included.",
    dateCreated: new Date().toLocaleDateString(),
    completed: false,
    dateCompleted: "",
  },
];
