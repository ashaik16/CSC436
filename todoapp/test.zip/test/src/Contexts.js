import React from "react";

export const StateContext = React.createContext({
  state: {},
  dispatch: () => {},
});
